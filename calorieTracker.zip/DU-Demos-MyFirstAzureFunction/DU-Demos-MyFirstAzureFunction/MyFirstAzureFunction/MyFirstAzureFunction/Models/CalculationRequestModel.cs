namespace MyFirstAzureFunction.Models;

public class CalculationRequestModel
{
    public string a { get; set; }
    public int b { get; set; }
}